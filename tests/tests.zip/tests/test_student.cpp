#include <catch2/catch_test_macros.hpp>

// You may write your own test cases in this file to test your code.
// Test cases in this file are not graded.

TEST_CASE("My Test Case", "") {
    bool student_wrote_test_case = true;

    REQUIRE( student_wrote_test_case );
}
